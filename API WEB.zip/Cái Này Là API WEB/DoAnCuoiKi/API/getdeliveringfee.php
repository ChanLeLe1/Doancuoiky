<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "doancuoiki";

// Tạo kết nối đến cơ sở dữ liệu
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối đến cơ sở dữ liệu thất bại: " . $conn->connect_error);
}

//Không đủ thời gian nên mình cho mặc định phí vận chuyển 30k nhé
$response = array(
    "data" => 30000,
    "status_code" => 200,
    "message" => "Lấy dữ liệu từ bảng thành công"
);

// Đặt tiêu đề cho phản hồi HTTP
header('Content-Type: application/json');

// Chuyển đổi mảng response thành chuỗi JSON và trả về
echo json_encode($response);

// Đóng kết nối
$conn->close();
