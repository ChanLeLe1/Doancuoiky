<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "doancuoiki";

// Đặt tiêu đề cho phản hồi HTTP
header("Content-Type: application/json");

// Kết nối tới cơ sở dữ liệu
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Kết nối tới cơ sở dữ liệu thất bại: " . $conn->connect_error);
}

$data_payment = json_decode($request->input("payment"));
$data_shipping = json_decode($request->input("shipping"));
$data_cart = json_decode($request->input("cart"));
$data_coupon = json_decode($request->input("coupon"));

// Thêm dữ liệu vào bảng payment
$sql = "INSERT INTO tbl_payment (payment_method, payment_status)
        VALUES ('$data_payment->payment_method', '$data_payment->payment_status')";
if ($conn->query($sql) === true) {
    $payment_id = $conn->insert_id;

    // Thêm dữ liệu vào bảng shipping
    $sql = "INSERT INTO tbl_shipping (shipping_name, shipping_phone, shipping_email, shipping_address, shipping_notes, shipping_special_requirements, shipping_receipt)
            VALUES ('$data_shipping->shipping_name', '$data_shipping->shipping_phone', '$data_shipping->shipping_email', '$data_shipping->shipping_address', '$data_shipping->shipping_notes', '$data_shipping->shipping_special_requirements', '$data_shipping->shipping_receipt')";
    if ($conn->query($sql) === true) {
        $shipping_id = $conn->insert_id;

        if ($data_coupon == null) {
            $coupon_name_code = "Không có";
        } else {
            $coupon_name_code = $data_coupon->coupon_name_code;
            $sql = "SELECT * FROM tbl_coupon WHERE coupon_name_code = '$coupon_name_code'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                $coupon_get = $result->fetch_assoc();
                if ($coupon_get["coupon_qty_code"] > 0) {
                    $coupon_get["coupon_qty_code"] -= 1;
                    $sql = "UPDATE tbl_coupon SET coupon_qty_code = '{$coupon_get["coupon_qty_code"]}' WHERE coupon_name_code = '$coupon_name_code'";
                    $conn->query($sql);
                }
            }
        }

        $order_code_rd = "ANDROID" . rand(1001, 9999);
        $total_quantity = 0;
        $total_price_product = 0;
        $customer_id = -1;

        // Lưu dữ liệu vào bảng orderdetails
        foreach ($data_cart as $cart) {
            $sql = "INSERT INTO tbl_orderdetails (order_code, product_id, product_name, product_price, product_sales_quantity)
                    VALUES ('$order_code_rd', '$cart->product_id', '$cart->product_name', '$cart->product_price', '$cart->product_quantity')";
            if ($conn->query($sql) === true) {
                $customer_id = $cart->customer_id;
                $total_quantity += $cart->product_quantity;
                $total_price_product +=
                    $cart->product_quantity * $cart->product_price;
            } else {
                return response()->json([
                    "data" => null,
                    "status_code" => 500,
                    "message" =>
                        "Lỗi trong quá trình thêm dữ liệu vào bảng orderdetails!",
                ]);
            }
        }
        // Thêm dữ liệu vào bảng order
        $sql = "INSERT INTO tbl_order (customer_id, shipping_id, payment_id, order_status, order_code, product_fee, product_coupon, product_price_coupon, total_price, total_quantity, order_date)
    VALUES ('$customer_id', '$shipping_id', '$payment_id', '0', '$order_code_rd', '{$request->deliveringfee}', '$coupon_name_code', ";

        if ($coupon_name_code == "Không có") {
            $sql .= "0";
        } else {
            if ($coupon_get["coupon_price_sale"] > 100) {
                $sql .= "'{$coupon_get["coupon_price_sale"]}', ";
                $total_price_product -= $coupon_get["coupon_price_sale"];
            } else {
                $sql .= "($total_price_product * {$coupon_get["coupon_price_sale"]}) / 100, ";
                $total_price_product -=
                    ($total_price_product * $coupon_get["coupon_price_sale"]) /
                    100;
            }
        }

        $sql .= "'$total_price_product', '$total_quantity', '6/16/2023')";

        if ($conn->query($sql) === true) {
            $sql = "SELECT * FROM tbl_order ORDER BY order_id DESC LIMIT 1";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $data = [];

                while ($row = $result->fetch_assoc()) {
                    $shipping_id = $row["shipping_id"];
                    $payment_id = $row["payment_id"];
                    $order_code = $row["order_code"];

                    $sql = "SELECT * FROM tbl_payment WHERE payment_id = '$payment_id'";
                    $payment_result = $conn->query($sql);
                    $payment = $payment_result->fetch_assoc();

                    $sql = "SELECT * FROM tbl_shipping WHERE shipping_id = '$shipping_id'";
                    $shipping_result = $conn->query($sql);
                    $shipping = $shipping_result->fetch_assoc();

                    $sql = "SELECT * FROM tbl_orderdetails WHERE order_code = '$order_code'";
                    $orderdetails_result = $conn->query($sql);
                    $data_order = [];

                    while (
                        $orderdetails_row = $orderdetails_result->fetch_assoc()
                    ) {
                        $data_order[] = [
                            "order_details_id" =>
                                $orderdetails_row["order_details_id"],
                            "order_code" => $orderdetails_row["order_code"],
                            "product_id" => $orderdetails_row["product_id"],
                            "product_name" => $orderdetails_row["product_name"],
                            "product_price" =>
                                $orderdetails_row["product_price"],
                            "product_image" =>
                                $orderdetails_row["product_image"],
                            "category_id" => $orderdetails_row["category_id"],
                            "category_name" =>
                                $orderdetails_row["category_name"],
                            "product_sales_quantity" =>
                                $orderdetails_row["product_sales_quantity"],
                            "created_at" => $orderdetails_row["created_at"],
                            "updated_at" => $orderdetails_row["updated_at"],
                        ];
                    }

                    $data[] = [
                        "order_id" => $row["order_id"],
                        "customer_id" => $row["customer_id"],
                        "shipping_id" => $row["shipping_id"],
                        "payment_id" => $row["payment_id"],
                        "order_status" => $row["order_status"],
                        "order_code" => $row["order_code"],
                        "product_fee" => $row["product_fee"],
                        "product_coupon" => $row["product_coupon"],
                        "product_price_coupon" => $row["product_price_coupon"],
                        "total_price" => $row["total_price"],
                        "total_quantity" => $row["total_quantity"],
                        "order_date" => $row["order_date"],
                        "shipping" => $shipping,
                        "payment" => $payment,
                        "orderDetails" => $data_order,
                        "created_at" => $row["created_at"],
                        "updated_at" => $row["updated_at"],
                    ];
                }
                return response()->json([
                    "data" => $data,
                    "status_code" => 200,
                    "message" => "Thành Công!",
                ]);
            } else {
                return response()->json([
                    "data" => null,
                    "status_code" => 404,
                    "message" => "Không có dữ liệu trả về!",
                ]);
            }
        } else {
            return response()->json([
                "data" => null,
                "status_code" => 500,
                "message" => "Lỗi trong quá trình thêm dữ liệu vào bảng order!",
            ]);
        }
    } else {
        return response()->json([
            "data" => null,
            "status_code" => 500,
            "message" => "Lỗi trong quá trình thêm dữ liệu vào bảng shipping!",
        ]);
    }
} else {
    return response()->json([
        "data" => null,
        "status_code" => 500,
        "message" => "Lỗi trong quá trình thêm dữ liệu vào bảng payment!",
    ]);
}
$conn->close();
?>
        
