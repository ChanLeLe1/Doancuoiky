<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "doancuoiki";

// Đặt tiêu đề cho phản hồi HTTP
header("Content-Type: application/json");


// Kết nối tới cơ sở dữ liệu
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Kết nối tới cơ sở dữ liệu thất bại: " . $conn->connect_error);
}

$customer_id = $_REQUEST['customer_id'];
$order_status = $_REQUEST['order_status'];
$order = null;

if ($order_status == -1) {
    $orderQuery = "SELECT * FROM tbl_order WHERE customer_id = $customer_id AND order_status IN ($order_status, 3) ORDER BY order_id DESC";
} else if ($order_status == 4) {
    $orderQuery = "SELECT * FROM tbl_order WHERE customer_id = $customer_id AND order_status IN ($order_status, 2) ORDER BY order_id DESC";
} else {
    $orderQuery = "SELECT * FROM tbl_order WHERE customer_id = $customer_id AND order_status = $order_status ORDER BY order_id DESC";
}

$orderResult = $conn->query($orderQuery);

if ($orderResult->num_rows > 0) {
    $data = array();

    while ($value = $orderResult->fetch_assoc()) {
        $shipping_id = $value['shipping_id'];
        $payment_id = $value['payment_id'];
        $order_code = $value['order_code'];

        $paymentQuery = "SELECT * FROM tbl_payment WHERE payment_id = $payment_id LIMIT 1";
        $paymentResult = $conn->query($paymentQuery);
        $payment = $paymentResult->fetch_assoc();

        $shippingQuery = "SELECT * FROM tbl_shipping WHERE shipping_id = $shipping_id LIMIT 1";
        $shippingResult = $conn->query($shippingQuery);
        $shipping = $shippingResult->fetch_assoc();

        $orderDetailsQuery = "SELECT * FROM tbl_orderdetails WHERE order_code = '$order_code'";
        $orderDetailsResult = $conn->query($orderDetailsQuery);

        $data_order = array();
        while ($v = $orderDetailsResult->fetch_assoc()) {
            $data_order[] = array(
                'order_details_id' => $v['order_details_id'],
                'order_code' => $v['order_code'],
                'product_id' => $v['product_id'],
                'product_name' => $v['product_name'],
                'product_price' => $v['product_price'],
                'product_image' => $v['product_image'],
                'category_id' => $v['category_id'],
                'category_name' => $v['category_name'],
                'product_sales_quantity' => $v['product_sales_quantity'],
                'created_at' => $v['created_at'],
                'updated_at' => $v['updated_at']
            );
        }

        $data[] = array(
            'order_id' => $value['order_id'],
            'customer_id' => $value['customer_id'],
            'shipping_id' => $value['shipping_id'],
            'payment_id' => $value['payment_id'],
            'order_status' => $value['order_status'],
            'order_code' => $value['order_code'],
            'product_fee' => $value['product_fee'],
            'product_coupon' => $value['product_coupon'],
            'product_price_coupon' => $value['product_price_coupon'],
            'total_price' => $value['total_price'],
            'total_quantity' => $value['total_quantity'],
            'order_date' => $value['order_date'],
            'shipping' => $shipping,
            'payment' => $payment,
            'orderDetails' => $data_order,
            'created_at' => $value['created_at'],
            'updated_at' => $value['updated_at']
        );
    }

    echo json_encode([
        'data' => $data,
        'status_code' => 200,
        'message' => 'Thành Công !'
    ]);

} else {
    echo json_encode([
        'data' => null,
        'status_code' => 404,
        'message' => 'Không có dữ liệu trả về !'
    ]);
}

$conn->close();
?>
