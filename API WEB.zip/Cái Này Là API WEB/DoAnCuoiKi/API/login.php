<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "doancuoiki";

// Lấy dữ liệu từ yêu cầu POST
$customer_name = $_POST['customer_name'];
$customer_password = $_POST['customer_password'];

// Tạo kết nối đến cơ sở dữ liệu
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    $response = array(
        "data" => null,
        "status_code" => 500,
        "message" => "Kết nối đến cơ sở dữ liệu thất bại"
    );
} else {
    $sql = "SELECT * FROM tbl_customers WHERE customer_name='$customer_name' AND customer_password ='$customer_password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // Lấy thông tin người dùng từ cơ sở dữ liệu
        $row = $result->fetch_assoc();

        // Trả về thông tin người dùng
        $response = array(
            "data" => $row,
            "status_code" => 200,
            "message" => "Đăng nhập thành công"
        );
    } else {
        // Thông tin đăng nhập không chính xác
        $response = array(
            "data" => null,
            "status_code" => 401,
            "message" => "Tên đăng nhập hoặc mật khẩu không đúng"
        );
    }
}

// Đặt tiêu đề cho phản hồi HTTP
header('Content-Type: application/json');

// Chuyển đổi mảng response thành chuỗi JSON và trả về
echo json_encode($response);

// Đóng kết nối
$conn->close();
