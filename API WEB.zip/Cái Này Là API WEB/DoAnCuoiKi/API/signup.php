<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "doancuoiki";

// Lấy dữ liệu từ yêu cầu POST
$customer_name = $_POST['customer_name'];
$customer_password = $_POST['customer_password'];
$customer_phone = $_POST['customer_phone'];
$customer_email = $_POST['customer_email'];

// Tạo kết nối đến cơ sở dữ liệu
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    $response = array(
        "data" => null,
        "status_code" => 500,
        "message" => "Kết nối đến cơ sở dữ liệu thất bại"
    );
} else {
    // Kiểm tra xem tên đăng nhập đã tồn tại chưa
    $sql = "SELECT * FROM tbl_customers WHERE customer_name='$customer_name'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $response = array(
            "data" => null,
            "status_code" => 409,
            "message" => "Tên đăng nhập đã tồn tại"
        );
    } else {
        // Tạo tài khoản mới
        $sql = "INSERT INTO tbl_customers (customer_name, customer_password, customer_phone, customer_email) 
                VALUES ('$customer_name', '$customer_password', '$customer_phone', '$customer_email')";
        if ($conn->query($sql) === TRUE) {
            $response = array(
                "data" => null,
                "status_code" => 200,
                "message" => "Tạo tài khoản thành công"
            );
        } else {
            $response = array(
                "data" => null,
                "status_code" => 500,
                "message" => "Lỗi tạo tài khoản: " . $conn->error
            );
        }
    }
}

// Trả về kết quả dưới dạng JSON
echo json_encode($response);
