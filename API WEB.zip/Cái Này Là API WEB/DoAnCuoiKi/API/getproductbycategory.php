<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "doancuoiki";

$category_id = $_GET['category_id'];

// Tạo kết nối đến cơ sở dữ liệu
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối đến cơ sở dữ liệu thất bại: " . $conn->connect_error);
}

$sql = "SELECT * FROM tbl_product WHERE category_id='$category_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Tạo mảng để lưu trữ dữ liệu
    $categories = array();

    // Lặp lại từng hàng kết quả và thêm vào mảng categories
    while($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }

    $response = array(
        "data" => $categories,
        "status_code" => 200,
        "message" => "Lấy dữ liệu từ bảng product thành công"
    );
} else {
    $response = array(
        "data" => null,
        "status_code" => 404,
        "message" => "Không tìm thấy dữ liệu trong bảng product"
    );
}

// Đặt tiêu đề cho phản hồi HTTP
header('Content-Type: application/json');

// Chuyển đổi mảng response thành chuỗi JSON và trả về
echo json_encode($response);

// Đóng kết nối
$conn->close();
